package ##{packageName};
import ##{commandManager);

}
public class ##{className} {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
