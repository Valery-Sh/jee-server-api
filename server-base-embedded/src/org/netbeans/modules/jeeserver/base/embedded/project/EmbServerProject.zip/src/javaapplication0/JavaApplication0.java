/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication0;

/**
 *
 * @author Valery
 */
public class JavaApplication0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
